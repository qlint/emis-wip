'use strict';

angular.module('eduwebApp').
controller('schoolBusCtrl', ['$scope', '$rootScope', 'apiService','$timeout','$window','$q','$parse',
function($scope, $rootScope, apiService, $timeout, $window, $q, $parse){

	var initialLoad = true;
	$scope.filters = {};
	$scope.filters.status = 'true';
	$scope.students = [];
	$scope.filterShowing = false;
	$scope.toolsShowing = false;
	var currentStatus = true;
	var isFiltered = false;	
	$rootScope.modalLoading = false;
	$scope.alert = {};
	$scope.refreshing = false;
	$scope.getReport = "examsTable";
	//$scope.loading = true;
	
	var initializeController = function () 
	{
		// get classes
		var requests = [];
		
		var deferred = $q.defer();
		requests.push(deferred.promise);
		
		if( $rootScope.allClasses === undefined )
		{
			if ( $rootScope.currentUser.user_type == 'TEACHER' )
			{
				apiService.getTeacherClasses($rootScope.currentUser.emp_id, function(response){
					var result = angular.fromJson(response);
					
					// store these as they do not change often
					if( result.response == 'success') 
					{
						$scope.classes = result.data || [];
						$scope.filters.class = $scope.classes[0];
						$scope.filters.class_id = ( $scope.classes[0] ? $scope.classes[0].class_id : null);
						deferred.resolve();
					}
					else
					{
						deferred.reject();
					}
					
				}, function(){deferred.reject();});
			}
			else
			{
				apiService.getAllClasses({}, function(response){
					var result = angular.fromJson(response);
					
					// store these as they do not change often
					if( result.response == 'success') 
					{
						$scope.classes = result.data || [];
						$scope.filters.class = $scope.classes[0];
						$scope.filters.class_id = ( $scope.classes[0] ? $scope.classes[0].class_id : null);
						$scope.filters.class_cat_id = ( $scope.classes[0] ? $scope.classes[0].class_cat_id : null);
						deferred.resolve();
					}
					else
					{
						deferred.reject();
					}
					
				}, function(){deferred.reject();});
			}
		}
		else
		{
			$scope.classes = $rootScope.allClasses;
			$scope.filters.class = $scope.classes[0];
			$scope.filters.class_id = $scope.classes[0].class_id;
			$scope.filters.class_cat_id = $scope.classes[0].class_cat_id;
			deferred.resolve();
		}

		
		// get terms
		var deferred2 = $q.defer();
		requests.push(deferred2.promise);
		if( $rootScope.terms === undefined )
		{
			apiService.getTerms(undefined, function(response,status)
			{
				var result = angular.fromJson(response);
				if( result.response == 'success')
				{ 
					$scope.terms = result.data;	
					$rootScope.terms = result.data;
					
					var currentTerm = $scope.terms.filter(function(item){
						if( item.current_term ) return item;
					})[0];
					$scope.filters.term_id = currentTerm.term_id;
					deferred2.resolve();
				}
				else
				{
					deferred2.reject();
				}
				
			}, function(){deferred2.reject();});
		}
		else
		{
			$scope.terms = $rootScope.terms;
			var currentTerm = $scope.terms.filter(function(item){
				if( item.current_term ) return item;
			})[0];
			$scope.filters.term_id = currentTerm.term_id;
			deferred2.resolve();
		}
		
		// get all active buses
		var getBusesParam = true;
		apiService.getAllBuses(getBusesParam, function(response,status){
			var result = angular.fromJson(response);
				
			if( result.response == 'success')
			{	
					$scope.allBuses = ( result.nodata ? [] : result.data );
					
			}
			else
			{
					$scope.error = true;
					$scope.errMsg = result.data;
			}
				
		}, apiError);
		
		// get all buses with assigned routes
		var getAssignedBusesParam = true;
		apiService.getAllAssignedBuses(getAssignedBusesParam, function(response,status){
			var result = angular.fromJson(response);
				
			if( result.response == 'success')
			{	
					$scope.allAssignedBuses = ( result.nodata ? [] : result.data );
					
			}
			else
			{
					$scope.error = true;
					$scope.errMsg = result.data;
			}
				
		}, apiError);
		
		// fetch existing active routes
    	var getRoutesParam = true;
		apiService.getActiveRoutes(getRoutesParam, function(response,status){
			var result = angular.fromJson(response);
				
			if( result.response == 'success')
			{	
					$scope.allRoutes = ( result.nodata ? [] : result.data );
					
			}
			else
			{
					$scope.error = true;
					$scope.errMsg = result.data;
			}
				
		}, apiError);
		
		var loadDrivers = function(response)
    	{
    		var result = angular.fromJson(response);
    
    		if( result.response == 'success')
    		{
    			$scope.drivers = ( result.nodata ? {} : result.data );
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    
    	}
		
		// fetch existing drivers
		apiService.getAllDrivers(true, loadDrivers, apiError);
		
		var loadBusAssistants = function(response)
    	{
    		var result = angular.fromJson(response);
    
    		if( result.response == 'success')
    		{
    			$scope.assistants = ( result.nodata ? {} : result.data );
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    
    	}
		
		// fetch existing employees (will double as bus assistants)
		apiService.getAllEmployeesExceptDrivers(true, loadBusAssistants, apiError);
		
		var loadBusesDriversAndRoutes = function(response)
    	{
    		var result = angular.fromJson(response);
    
    		if( result.response == 'success')
    		{
    			$scope.transportDataTable = ( result.nodata ? {} : result.data );
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    
    	}
		
		// fetch existing drivers
		apiService.getAllBusesRoutesAndDrivers(true, loadBusesDriversAndRoutes, apiError);
		
	}
	$timeout(initializeController,1);

	$scope.$watch('filters.class',function(newVal,oldVal){
		if( newVal == oldVal ) return;

		$scope.filters.class_id = newVal.class_id;

		apiService.getExamTypes(newVal.class_cat_id, function(response){
			var result = angular.fromJson(response);
			if( result.response == 'success' && !result.nodata ){ 
				$scope.examTypes = result.data;
				$scope.filters.exam_type_id = $scope.examTypes[0].exam_type_id;
				$timeout(setSearchBoxPosition,10);
			}
		}, apiError);
		
		
	});
	
	// hide the timetable setup until the class and term are selected
	// var ttView = document.getElementsByClassName("ttView")[0];
	// ttView.style.display = "none";
	
	$scope.setUpTt = function(){
	    
	}
	
	var addBusSuccess = function ( response, status, params )
    	{
    
    		var result = angular.fromJson( response );
    		if( result.response == 'success' )
    		{
    			
                $scope.busCreation = true;
                
                // we allow the success message to be visible only for a duration
                setTimeout(function(){ $scope.busCreation = false; }, 4000);
                $timeout(initializeController,1);
    
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    	}
    
    // variable for showing or hiding bus creation success message
    $scope.busCreation = false;
    
    $scope.createBus = function()
	{
    	
	    // acquire the input values
	    var busType = $( "#busType" ).val().toUpperCase();
	    var busRegistration = $( "#busReg" ).val().toUpperCase();
	    
	    var busData = {
	        "bus_type": busType,
	        "bus_registration": busRegistration
	    };
	    
		apiService.createSchoolBus(busData,addBusSuccess,apiError);
	}
	
	var assignSuccess = function ( response, status, params )
    	{
    
    		var result = angular.fromJson( response );
    		if( result.response == 'success' )
    		{
    			
                $scope.routeAssignment = true;
                
                // we allow the success message to be visible only for a duration
                setTimeout(function(){ $scope.routeAssignment = false; }, 4000);
                $timeout(initializeController,1);
    
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    	}
	
	// variable for showing or hiding bus-route assignment success message
    $scope.routeAssignment = false;
    
	$scope.assignRoute = function()
	{
    	
	    // acquire the input values
	    var busId = $( "#theBusId" ).val();
	    var routeId = $( "#theRouteId" ).val();
	    
	    var assignData = {
	        "bus_id": busId,
	        "route_id": parseInt(routeId)
	    };
		apiService.assignBusToRoute(assignData,assignSuccess,apiError);
	}
	
	var initDataGrid = function() 
	{
		
		var tableElement = $('#resultsTable');
		$scope.dataGrid = tableElement.DataTable( {
				responsive: {
					details: {
						type: 'column'
					}
				},
				columnDefs: [ {
					className: 'control',
					orderable: false,
					targets:   0
				} ],
				paging: false,
				destroy:true,
				order: [2,'asc'],
				filter: true,
				info: false,
				sorting:[],
				initComplete: function(settings, json) {
					$scope.loading = false;
					$rootScope.loading = false;
					$scope.$apply();
				},
				language: {
						search: "Search Results<br>",
						searchPlaceholder: "Filter",
						lengthMenu: "Display _MENU_",
						emptyTable: "No students found."
				},
			} );
			
		
		var headerHeight = $('.navbar-fixed-top').height();
		//var subHeaderHeight = $('.subnavbar-container.fixed').height();
		var searchHeight = $('#body-content .content-fixed-header').height();
		var offset = ( $rootScope.isSmallScreen ? 22 : 13 );
		new $.fn.dataTable.FixedHeader( $scope.dataGrid, {
				header: true,
				headerOffset: (headerHeight + searchHeight) + offset
			} );
		
		
		// position search box
		setSearchBoxPosition();
		
		if( initialLoad ) setResizeEvent();
		
	}
	
	var setSearchBoxPosition = function()
	{
		if( !$rootScope.isSmallScreen )
		{
			var filterFormWidth = $('.dataFilterForm form').width();
			$('#resultsTable_filter').css('left',filterFormWidth+55);
		}
	}
	
	var setResizeEvent = function()
	{
		 initialLoad = false;

		 $window.addEventListener('resize', function() {
			
			$rootScope.isSmallScreen = (window.innerWidth < 768 ? true : false );
			if( $rootScope.isSmallScreen )
			{
				$('#resultsTable_filter').css('left',0);
			}
			else
			{
				var filterFormWidth = $('.dataFilterForm form').width();
				$('#resultsTable_filter').css('left',filterFormWidth-30);	
			}
		}, false);
	}
	
			
	$scope.toggleFilter = function()
	{
		$scope.filterShowing = !$scope.filterShowing;
		
		if( $scope.filterShowing || $scope.toolsShowing )
		{
			$('#resultsTable_filter').hide();
		}
		else
		{
			$timeout( function()
			{
				$('#resultsTable_filter').show()
			},500);
		}
	}
	
	$scope.toggleTools = function()
	{
		$scope.toolsShowing = !$scope.toolsShowing;
		
		if( $scope.filterShowing || $scope.toolsShowing )
		{
			$('#resultsTable_filter').hide();
		}
		else
		{
			$timeout( function()
			{
				$('#resultsTable_filter').show()
			},500);
		}
	}
	
	$scope.addExamMarks = function()
	{
		var data = {
			classes: $scope.classes,
			terms: $scope.terms,
			examTypes: $scope.examTypes,
			filters: $scope.filters
		}
		$scope.openModal('exams', 'addExamMarks', 'lg', data);
	}
	
	var assignPersonnelSuccess = function ( response, status, params )
    	{
    
    		var result = angular.fromJson( response );
    		if( result.response == 'success' )
    		{
    			
                $scope.assignedPersonnel = true;
                
                // we allow the success message to be visible only for a duration
                setTimeout(function(){ $scope.assignedPersonnel = false; }, 3000);
                $timeout(initializeController,1);
    
    		}
    		else
    		{
    			$scope.error = true;
    			$scope.errMsg = result.data;
    		}
    	}
	
	$scope.assignDriverAndGuide = function()
	{
		// acquire the input values
	    var selectedBus = $( "#routedBuses" ).val();
	    var selectedDriver = $( "#allDrivers" ).val();
	    var selectedAssistant = $( "#theAssistant" ).val();
	    
	    var assignData = {
	        "bus_id": selectedBus,
	        "bus_driver": selectedDriver,
	        "bus_guide": selectedAssistant
	    };
	    
		apiService.assignPersonnelToBus(assignData,assignPersonnelSuccess,apiError);
	}
	
	$scope.exportData = function()
	{
		$rootScope.wipNotice();
	}
	
	$scope.$on('refreshExamMarks', function(event, args) {

		$scope.loading = true;
		$rootScope.loading = true;
		
		if( args !== undefined )
		{
			$scope.updated = true;
			$scope.notificationMsg = args.msg;
		}
		$scope.refresh();
		
		// wait a bit, then turn off the alert
		$timeout(function() { $scope.alert.expired = true;  }, 2000);
		$timeout(function() { 
			$scope.updated = false;
			$scope.notificationMsg = ''; 
			$scope.alert.expired = false;
		}, 3000);
	});
	
	$scope.refresh = function () 
	{
		$scope.loading = true;
		$scope.refreshing = true;
		$rootScope.loading = true;
		$scope.getStudentExams();
	}
	
	var apiError = function (response, status) 
	{
		var result = angular.fromJson( response );
		$scope.error = true;
		$scope.errMsg = result.data;
	}
	
	$scope.$on('$destroy', function() {
		if($scope.dataGrid){
			$('.fixedHeader-floating').remove();
			$scope.dataGrid.fixedHeader.destroy();
			$scope.dataGrid.clear();
			$scope.dataGrid.destroy();
		}
		$rootScope.isModal = false;
    });
	

} ]);