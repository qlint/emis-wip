Your Slim Framework application's template cache files will be written to this directory.
